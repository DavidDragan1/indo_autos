<?php defined('BASEPATH') OR exit('No direct script access allowed');

// leave blank for module helper
/* function myHelper(){
    return 'MyHelper';
}
*/

