<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<section class="content-header">
    <h1> Acls  <small><?php echo $button ?></small> <a href="<?php echo site_url('admin/acls') ?>" class="btn btn-default">Back</a> </h1>
    <ol class="breadcrumb">
        <li><a href="admin/"><i class="fa fa-dashboard"></i> Admin</a></li>
        <li><a href="admin/acls">Acls</a></li>
        <li class="active">Add New</li>
    </ol>
</section>

<section class="content">       
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Add New Record</h3>
        </div>
        
        <div class="box-body">
        <form class="form-horizontal" action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
                    <label for="module_id" class="col-sm-2 control-label">Module Id :</label>
                    <div class="col-sm-10">                    
                        <input type="text" class="form-control" name="module_id" id="module_id" placeholder="Module Id" value="<?php echo $module_id; ?>" />
                        <?php echo form_error('module_id') ?>
                    </div>
                </div>
	    <div class="form-group">
                    <label for="permission_name" class="col-sm-2 control-label">Permission Name :</label>
                    <div class="col-sm-10">                    
                        <input type="text" class="form-control" name="permission_name" id="permission_name" placeholder="Permission Name" value="<?php echo $permission_name; ?>" />
                        <?php echo form_error('permission_name') ?>
                    </div>
                </div>
	    <div class="form-group">
                    <label for="permission_key" class="col-sm-2 control-label">Permission Key :</label>
                    <div class="col-sm-10">                    
                        <input type="text" class="form-control" name="permission_key" id="permission_key" placeholder="Permission Key" value="<?php echo $permission_key; ?>" />
                        <?php echo form_error('permission_key') ?>
                    </div>
                </div>
	    <div class="form-group">
                    <label for="order_id" class="col-sm-2 control-label">Order Id :</label>
                    <div class="col-sm-10">                    
                        <input type="text" class="form-control" name="order_id" id="order_id" placeholder="Order Id" value="<?php echo $order_id; ?>" />
                        <?php echo form_error('order_id') ?>
                    </div>
                </div>
	<div class="col-md-12 text-right">    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('admin/acls') ?>" class="btn btn-default">Cancel</a>
	</div></form>
	</div></div></section>