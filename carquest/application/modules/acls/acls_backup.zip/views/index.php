<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<section class="content-header">
    <h1> Acls  <small>Control panel</small> <?php echo anchor(site_url(Backend_URL.'acls/create'),' + Add New', 'class="btn btn-default"'); ?> </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo Backend_URL ?>"><i class="fa fa-dashboard"></i> Admin</a></li>
        <li class="active">Acls</li>
    </ol>
</section>

<section class="content">
<div class="box" style="margin-bottom: 10px">
             
        <div class="box-header">          
            <div class="col-md-4 text-right">
	    
            </div>    
        </div>
    
    <div class="box-body">
    <div class="">
        <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="20px">ID</th>
					<th>Module Name</th>
					<th>Permission Name</th>
					<th>Permission Key</th>
					<th>Order</th>
					<th width="60">Action</th>
                </tr>
            </thead>
	    <tbody>
            <?php foreach ($acls_data as $acls) {  ?>
                <tr>
				<td><?php echo $acls->id ?></td>
				<td><?php echo $acls->name ?></td>
				<td><?php echo $acls->permission_name ?></td>
				<td><?php echo $acls->permission_key ?></td>
				<td><?php echo $acls->order_id ?></td>
				<td>
				<?php 					
					echo anchor(site_url( Backend_URL .'acls/update/'.$acls->id),'<i class="fa fa-fw fa-edit"></i>',  'class="btn btn-xs btn-default"'); 
					echo anchor(site_url( Backend_URL .'acls/delete/'.$acls->id),'<i class="fa fa-fw fa-trash"></i>', 'class="btn btn-xs btn-danger" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'); 
				?>
				</td>
				</tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    </div>
</div>
</section>
        
        <script type="text/javascript">
            $(document).ready(function () {
                $("#mytable").dataTable();
            });
        </script>