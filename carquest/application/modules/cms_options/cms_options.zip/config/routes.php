<?php


$route['admin/cms/category']         = 'cms_options';
$route['admin/cms/create']          = 'cms_options/create';
$route['admin/cms/read/(:any)']     = 'cms_options/read/$1';
$route['admin/cms/delete']          = 'cms_options/delete';
$route['admin/cms/update/(:any)']   = 'cms_options/update/$1';

$route['admin/cms/create_action']          = 'cms_options/create_action';
$route['admin/cms/update_action']          = 'cms_options/update_action';




